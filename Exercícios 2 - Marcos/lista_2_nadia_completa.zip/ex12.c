#include <stdio.h>
#include <stdlib.h>

main()
{
    int k=0, n=0, positivos=0;
    float somaImpares=0, quantidadeImpares=0;

    while(k<=0){
        system("clear");
        printf("Digite a quantidade de termos com a qual deseja entrar: ");
        scanf("%d", &k);
    }
}
